<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
	$query = "insert into teacher values('',$_POST[Tid],'$_POST[Fname]','$_POST[Lname]',$_POST[Phone_Num],'$_POST[Email]','$_POST[password]','$_POST[DOB]','$_POST[Qualification]','$_POST[Gender]','$_POST[Salary]','$_POST[Staff_id]')";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Teacher added successfully.");
	window.location.href = "admin_dashboard.php";
</script>
