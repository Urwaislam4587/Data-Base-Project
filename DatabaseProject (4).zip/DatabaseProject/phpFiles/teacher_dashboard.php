<!DOCTYPE html>
<html>
<head>
	<title>Teacher Dashboard</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		#header{
			height: 10%;
			width: 100%;
			top: 2%;
			background-color: black;
			position: fixed;
			color: white;
		}
		#left_side{
			height: 75%;
			width: 15%;
			top: 10%;
			position: fixed;
		}
		#right_side{
			height: 75%;
			width: 80%;
			background-color: whitesmoke;
			position: fixed;
			left: 17%;
			top: 21%;
			color: red;
			border: solid 1px black;
		}
		#top_span{
			top: 15%;
			width: 80%;
			left: 17%;
			position: fixed;
		}
		#td{
			border: 1px solid black;
			padding-left: 2px;
			text-align: left;
			width: 200px;
		}
	</style>
	<?php
		session_start();
		$name = "";
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"sms");
	?>
</head>
<body>
	<div id="header"><br>
		<center>Student Management System &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		<a href="logout.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
		</center>
	</div>
	<span id="top_span"><marquee> Welcome to Teachers Portal.</marquee></span>
	<div id="left_side">
		<br><br><br>
		<form action="" method="post">
			<table>
				<tr>
					<td>
						<input type="submit" name="search_student" value="Search Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_grade" value="Add Grade">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="edit_grade" value="Edit Grade">
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div id="right_side"><br><br>
		<div id="demo">
		<!-- #Code for search student---Start-->
			<?php
				if(isset($_POST['search_student']))
				{
					?>
					<center>
					<form action="" method="post">
					&nbsp;&nbsp;<b>Enter Roll No:</b>&nbsp;&nbsp; <input type="text" name="roll_no">
					<input type="submit" name="search_by_roll_no_for_search" value="Search">
					</form><br><br>
					<h4><b><u>Student's details</u></b></h4><br><br>
					</center>
					<?php
				}
				if(isset($_POST['search_by_roll_no_for_search']))
				{
					$query = "select * from Student where Sid = '$_POST[roll_no]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<table>
							<tr>
								<td>
									<b>Roll No:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Sid']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>First Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Fname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Last Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Lname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>DOB:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['DOB']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Address:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['address']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Password:</b>
								</td> 
								<td>
									<input type="password" value="<?php echo $row['Password']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Parent_id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Parent_id']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Phone_Num:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Phone_Num']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Joining_Date:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Joining_Date']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Email:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Email']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Gender:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Gender']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Exam_id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Exam_Id']?>" disabled>
								</td>
							</tr>
						</table>
						<?php
					}
				}
			?>
		<!-- #Code for add grade---Start-->
		<?php 
				if(isset($_POST['add_grade'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_grade.php" method="post">
						<table>
						<tr>
							<td>
								<b>Student id:</b>
							</td> 
							<td>
								<input type="text" name="Student_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Course id:</b>
							</td> 
							<td>
								<input type="text" name="Course_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Grade:</b>
							</td> 
							<td>
								<input type="text" name="Grade_Name" required>
							</td>
						</tr>
						
							<td></td>
							<td><br><input type="submit" name="add" value="Add Grade"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
		<!-- #Code for edit student Grades---Start-->
		<?php
			if(isset($_POST['edit_grade']))
			{
				?>
				<center>
				<form action="" method="post">
				&nbsp;&nbsp;<b>Enter Roll No:</b>&nbsp;&nbsp; <input type="text" name="roll_no">
				<b>Enter Course_id:</b>&nbsp;&nbsp; <input type="text" name="Course_id">
				<input type="submit" name="search_by_roll_no_for_edit" value="Search">
				</form><br><br>
				<h4><b><u>Grade details</u></b></h4><br><br>
				</center>
				<?php
			}
			if(isset($_POST['search_by_roll_no_for_edit']))
			{
				$query = "select * from Grade where Student_id = $_POST[roll_no] ";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					?>
					<form action="teacher_edit_grade.php" method="post">
					<table>
						<tr>
							<td>
								<b>Roll No:</b>
							</td> 
							<td>
								<input type="text" name="roll_no" value="<?php echo $row['Student_id']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Course_id:</b>
							</td> 
							<td>
								<input type="text" name="roll_no" value="<?php echo $row['Course_id']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Grade:</b>
							</td> 
							<td>
								<input type="text" name="roll_no" value="<?php echo $row['Grade_Name']?>">
							</td>
						</tr>
						<tr>
							<td></td>
							<td>
								<input type="submit" name="edit" value="Save">
							</td>
						</tr>
					</table>
					</form>
					<?php
				}
			}
		?>
		</div>
	</div>
</body>
</html>