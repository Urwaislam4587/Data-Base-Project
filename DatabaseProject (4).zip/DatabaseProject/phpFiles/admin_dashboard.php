<!DOCTYPE html>
<html>
<head>
	<title>Admin Dashboard</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		#header{
			height: 10%;
			width: 100%;
			top: 2%;
			background-color: black;
			position: fixed;
			color: white;
		}
		#left_side{
			height: 75%;
			width: 15%;
			top: 10%;
			position: fixed;
		}
		#right_side{
			height: 75%;
			width: 80%;
			background-color: whitesmoke;
			position: fixed;
			left: 17%;
			top: 21%;
			color: red;
			border: solid 1px black;
		}
		#top_span{
			top: 15%;
			width: 80%;
			left: 17%;
			position: fixed;
		}
		#td{
			border: 1px solid black;
			padding-left: 2px;
			text-align: left;
			width: 200px;
		}
	</style>
	<?php
		session_start();
		$name = "";
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"sms");
	?>
</head>
<body>
	<div id="header"><br>
		<center>Student Management System &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;            
		<a href="logout.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
		</center>
	</div>
	<span id="top_span"><marquee> welcome To Admin Portal.</marquee></span>
	<div id="left_side">
		<br><br><br>
		<form action="" method="post">
			<table>
				<tr>
					<td>
						<input type="submit" name="search_student" value="Search Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="edit_student" value="Edit Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_new_student" value="Add New Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="delete_student" value="Delete Student">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="show teacher" value="Show Teachers">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="edit_teacher" value="Edit Teacher">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="delete_teacher" value="Delete Teacher">
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="add_new_teacher" value="Add Teacher">
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div id="right_side"><br><br>
		<div id="demo">
		<!-- #Code for search student---Start-->
			<?php
				if(isset($_POST['search_student']))
				{
					?>
					<center>
					<form action="" method="post">
					&nbsp;&nbsp;<b>Enter Roll No:</b>&nbsp;&nbsp; <input type="text" name="roll_no">
					<input type="submit" name="search_by_roll_no_for_search" value="Search">
					</form><br><br>
					<h4><b><u>Student's details</u></b></h4><br><br>
					</center>
					<?php
				}
				if(isset($_POST['search_by_roll_no_for_search']))
				{
					$query = "select * from Student where Sid = '$_POST[roll_no]'";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<table>
							<tr>
								<td>
									<b>Roll No:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Sid']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>First Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Fname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Last Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Lname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Date of Birth:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['DOB']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Address:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['address']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Email:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Email']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Password:</b>
								</td> 
								<td>
									<input type="password" value="<?php echo $row['Password']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Parent id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Parent_id']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Joining_Date:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Joining_Date']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Gender:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Gender']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Fee:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['fee']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Exam_id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Exam_Id']?>" disabled>
								</td>
							</tr>
							
						</table>
						<?php
					}
				}
			?>
		<!-- #Code for edit student details---Start-->
		<?php
			if(isset($_POST['edit_student']))
			{
				?>
				<center>
				<form action="" method="post">
				&nbsp;&nbsp;<b>Enter Roll No:</b>&nbsp;&nbsp; <input type="text" name="roll_no">
				<input type="submit" name="search_by_roll_no_for_edit" value="Search">
				</form><br><br>
				<h4><b><u>Student's details</u></b></h4><br><br>
				</center>
				<?php
			}
			if(isset($_POST['search_by_roll_no_for_edit']))
			{
				$query = "select * from Student where Sid = $_POST[roll_no]";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					?>
					<form action="admin_edit_student.php" method="post">
						<table>
						<tr>
							<td>
								<b>Roll No:</b>
							</td> 
							<td>
								<input type="text" name="roll_no" value="<?php echo $row['Sid']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>First Name:</b>
							</td> 
							<td>
								<input type="text" name="Fname" value="<?php echo $row['Fname']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Last Name:</b>
							</td> 
							<td>
								<input type="text" name="Lname" value="<?php echo $row['Lname']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>DOB:</b>
							</td> 
							<td>
								<input type="text" name="DOB" value="<?php echo $row['DOB']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Address:</b>
							</td> 
							<td>
								<input type="text" name="address" value="<?php echo $row['address']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Password:</b>
							</td> 
							<td>
								<input type="password" name="password" value="<?php echo $row['Password']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Parent id:</b>
							</td> 
							<td>
								<input type="text" name="Parent_id" value="<?php echo $row['Parent_id']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Phone Number:</b>
							</td> 
							<td>
								<input type="text" name="Phone_Num" value="<?php echo $row['Phone_Num']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Joining_Date:</b>
							</td> 
							<td>
								<input type="text" name="Joining_Date" value="<?php echo $row['Joining_Date']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="Email" value="<?php echo $row['Email']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Gender:</b>
							</td> 
							<td>
								<input type="text" name="Gender" value="<?php echo $row['Gender']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Fee:</b>
							</td> 
							<td>
								<input type="text" name="fee" value="<?php echo $row['fee']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Exam_id:</b>
							</td> 
							<td>
								<input type="text" name="Exam_Id" value="<?php echo $row['Exam_Id']?>">
							</td>
						</tr><br>
						<tr>
							<td></td>
							<td>
								<input type="submit" name="edit" value="Save">
							</td>
						</tr>
					</table>
					</form>
					<?php
				}
			}
		?>
		<!-- #Code for Delete student details---Start-->
		<?php
			if(isset($_POST['delete_student']))
			{
				?>
				<center>
				<form action="delete_student.php" method="post">
				&nbsp;&nbsp;<b>Enter Roll No:</b>&nbsp;&nbsp; <input type="text" name="roll_no">
				<input type="submit" name="search_by_roll_no_for_delete" value="Delete">
				</form><br><br>
				</center>
				<?php
			}
			?>

			<?php 
				if(isset($_POST['add_new_student'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_student.php" method="post">
						<table>
						<tr>
							<td>
								<b>Roll No:</b>
							</td> 
							<td>
								<input type="text" name="Sid" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>First Name:</b>
							</td> 
							<td>
								<input type="text" name="Fname" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Last Name:</b>
							</td> 
							<td>
								<input type="text" name="Lname" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>DOB:</b>
							</td> 
							<td>
								<input type="text" name="DOB" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Address:</b>
							</td> 
							<td>
								<input type="text" name="address" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Password:</b>
							</td> 
							<td>
								<input type="password" name="Password" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Parent_id:</b>
							</td> 
							<td>
								<input type="text" name="Parent_id" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Phone_Num:</b>
							</td> 
							<td>
								<input type="text" name="Phone_Num" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Joining_Date:</b>
							</td> 
							<td>
								<input type="text" name="Joining_Date" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="Email" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Gender:</b>
							</td> 
							<td>
								<input type="text" name="Gender" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Fee:</b>
							</td> 
							<td>
								<input type="text" name="fee" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Exam_Id:</b>
							</td> 
							<td>
								<input type="text" name="Exam_Id" required>
							</td>
						</tr>
							<td></td>
							<td><br><input type="submit" name="add" value="Add Student"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
			<?php
				if(isset($_POST['show_teacher']))
				{
					?>
					<center>
						<h5>Teacher's Details</h5>
						<table>
							<tr>
								<td id="td"><b>ID</b></td>
								<td id="td"><b>Name</b></td>
								<td id="td"><b>Mobile</b></td>
								<td id="td"><b>Courses</b></td>
								<td id="td"><b>View Detail</b></td>
							</tr>
						</table>
					</center>
					<?php
					$query = "select * from Teacher";
					$query_run = mysqli_query($connection,$query);
					while ($row = mysqli_fetch_assoc($query_run)) 
					{
						?>
						<center>
						<table style="border-collapse: collapse;border: 1px solid black;">
							<tr>
								<td id="td"><?php echo $row['Tid']?></td>
								<td id="td"><?php echo $row['Fname']?></td>
								<td id="td"><?php echo $row['Lname']?></td>
								<td id="td"><?php echo $row['Email']?></td>
								<td id="td"><a href="#">View</a></td>
							</tr>
						</table>
						</center>
						<?php
					}
				}
			?>
			<!-- #Code for Edit Teacher ---Start-->
			<?php
				if(isset($_POST['edit_teacher']))
			{
				?>
				<center>
				<form action="" method="post">
				&nbsp;&nbsp;<b>Enter Teachers id:</b>&nbsp;&nbsp; <input type="text" name="id">
				<input type="submit" name="search_by_id_for_edit" value="Search">
				</form><br><br>
				<h4><b><u>Teachers's details</u></b></h4><br><br>
				</center>
				<?php
			}
			if(isset($_POST['search_by_id_for_edit']))
			{
				$query = "select * from teacher where Tid = $_POST[id]";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
					?>
					<form action="admin_edit_teacher.php" method="post">
						<table>
						<tr>
							<td>
								<b>id:</b>
							</td> 
							<td>
								<input type="text" name="id" value="<?php echo $row['Tid']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>First_name:</b>
							</td> 
							<td>
								<input type="text" name="First name" value="<?php echo $row['Fname']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Last_name:</b>
							</td> 
							<td>
								<input type="text" name="Last name" value="<?php echo $row['Lname']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Phone_Num:</b>
							</td> 
							<td>
								<input type="text" name="Phone_Num" value="<?php echo $row['Phone_Num']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="Email" value="<?php echo $row['Email']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Password:</b>
							</td> 
							<td>
								<input type="password" name="password" value="<?php echo $row['Password']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>DOB:</b>
							</td> 
							<td>
								<input type="text" name="DOB" value="<?php echo $row['DOB']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Qualification:</b>
							</td> 
							<td>
								<input type="text" name="Qualification" value="<?php echo $row['Qualification']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Gender:</b>
							</td> 
							<td>
								<input type="text" name="Gender" value="<?php echo $row['Gender']?>">
							</td>
						</tr>
						<tr>
							<td>
								<b>Salary:</b>
							</td> 
							<td>
								<input type="text" name="Salary" value="<?php echo $row['Salary']?>">
							</td>
						</tr>
						<tr>
							<td></td>
							<td>
								<input type="submit" name="edit" value="Save">
							</td>
						</tr>
					</table>
					</form>
					<?php
				}
			}
			?>
			<!-- #Code for Delete Teacher ---Start-->
			<?php
			    if(isset($_POST['delete_teacher']))
				{
				?>
				<center>
				<form action="delete_teacher.php" method="post">
				&nbsp;&nbsp;<b>Enter Id:</b>&nbsp;&nbsp; <input type="text" name="Id">
				<input type="submit" name="search_by_id_for_delete" value="Delete">
				</form><br><br>
				</center>
				<?php
			    }
            ?>
			<!-- #Code for Add Teacher ---Start-->
			<?php 
				if(isset($_POST['add_new_teacher'])){
					?>
					<center><h4>Fill the given details</h4></center>
					<form action="add_teacher.php" method="post">
						<table>
						<tr>
							<td>
								<b>Id:</b>
							</td> 
							<td>
								<input type="text" name="Tid" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>First Name:</b>
							</td> 
							<td>
								<input type="text" name="Fname" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Last Name:</b>
							</td> 
							<td>
								<input type="text" name="Lname" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Phone_Num:</b>
							</td> 
							<td>
								<input type="text" name="Phone_Num" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Email:</b>
							</td> 
							<td>
								<input type="text" name="Email" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Password:</b>
							</td> 
							<td>
								<input type="password" name="password" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Date of Birth:</b>
							</td> 
							<td>
								<input type="text" name="DOB" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Qualification:</b>
							</td> 
							<td>
								<input type="text" name="Qualification" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Gender:</b>
							</td> 
							<td>
								<input type="text" name="Gender" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Salary:</b>
							</td> 
							<td>
								<input type="text" name="Salary" required>
							</td>
						</tr>
						<tr>
							<td>
								<b>Staff_id:</b>
							</td> 
							<td>
								<input type="text" name="Staff_id" required>
							</td>
						</tr>
						<tr>
							<td></td>
							<td><br><input type="submit" name="add" value="Add Teacher"></td>
						</tr>
					</table>
					</form>
					<?php
				}
			?>
		</div>
	</div>
</body>
</html>