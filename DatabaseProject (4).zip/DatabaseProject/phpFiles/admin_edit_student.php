<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
	$query = "update Student set Fname='$_POST[Fname]',Lname='$_POST[Lname]',DOB=$_POST[DOB],address='$_POST[address]',password='$_POST[password]',Parent_id='$_POST[Parent_id]',Phone_Num='$_POST[Phone_Num]',Joining_Date='$_POST[Joining_Date]',Email='$_POST[Email]',Gender='$_POST[Gender]',fee='$_POST[fee]',Exam_Id='$_POST[Exam_Id]' where Sid = $_POST[roll_no]";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Details edited successfully.");
	window.location.href = "admin_dashboard.php";
</script>
