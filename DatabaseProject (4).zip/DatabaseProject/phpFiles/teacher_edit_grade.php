<!DOCTYPE html>
<html>
<head>
	<title>Enter fields</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<center><br><br>
		<h3>*****</h3><br>
		<form action="" method="post">
			Course_id: <input type="text" name="Course_id" required><br><br>
			<input type="submit" name="submit" value="Enter">
		</form><br>

<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
    $query = " update Grade set Grade_Name='$_POST[Grade_Name]' where Sid = $_POST[roll_no]";
	$query_run = mysqli_query($connection,$query);
	
?>
<script type="text/javascript">
	alert("Details edited successfully.");
	window.location.href = "teacher_dashboard.php";
</script>
