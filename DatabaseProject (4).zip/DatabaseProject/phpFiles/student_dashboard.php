<!DOCTYPE html>
<html>
<head>
	<title>Student Dashboard</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="bootstrap-4.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		#header{
			height: 10%;
			width: 100%;
			top: 2%;
			background-color: black;
			position: fixed;
			color: white;
		}
		#left_side{
			height: 75%;
			width: 15%;
			top: 10%;
			position: fixed;
		}
		#right_side{
			height: 75%;
			width: 80%;
			background-color: whitesmoke;
			position: fixed;
			left: 17%;
			top: 21%;
			color: red;
			border: solid 1px black;
		}
		#top_span{
			top: 15%;
			width: 80%;
			left: 17%;
			position: fixed;
		}
	</style>
	<?php
		session_start();
		$connection = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($connection,"sms");
	?>
</head>
<body>
	<div id="header"><br>
		<center>Student Management System &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp 
		<a href="logout.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
		</center>
	</div>
	<span id="top_span"><marquee>Welcome to student Portal</marquee></span>
	<div id="left_side">
		<br><br><br>
		<form action="" method="post">
		
			<table>
				<tr>
					<td>
						<input type="submit" name="show_detail" value="Show Detail">
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div id="right_side"><br><br>
		<div id="demo">
			<?php
			if(isset($_POST['show_detail']))
			{
				$query = "select * from Student where Email = '$_SESSION[email]'";
				$query_run = mysqli_query($connection,$query);
				while ($row = mysqli_fetch_assoc($query_run)) 
				{
			    ?>
						<table>
							<tr>
								<td>
									<b>Roll No:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Sid']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>First Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Fname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Last Name:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Lname']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Date of Birth:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['DOB']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Address:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['address']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Email:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Email']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Password:</b>
								</td> 
								<td>
									<input type="password" value="<?php echo $row['password']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Parent id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Parent_id']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Joining_Date:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Joining_Date']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Gender:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Gender']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Fee:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['fee']?>" disabled>
								</td>
							</tr>
							<tr>
								<td>
									<b>Exam_id:</b>
								</td> 
								<td>
									<input type="text" value="<?php echo $row['Exam_Id']?>" disabled>
								</td>
							</tr>
							
						</table>
				<?php
				}	
			}
			?>
		</div>
	</div>
</body>
</html>