<?php
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,"sms");
	$query = "insert into Student values('',$_POST[Sid],'$_POST[Fname]','$_POST[Lname]',$_POST[DOB],'$_POST[address]','$_POST[Password]','$_POST[Parent_id]','$_POST[Phone_Num]','$_POST[Joining_Date]','$_POST[Email]','$_POST[Gender]','$_POST[fee]','$_POST[Exam_Id]')";
	$query_run = mysqli_query($connection,$query);
?>
<script type="text/javascript">
	alert("Student added successfully.");
	window.location.href = "admin_dashboard.php";
</script>
