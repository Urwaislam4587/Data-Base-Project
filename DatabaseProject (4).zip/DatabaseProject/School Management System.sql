create database sms;
use sms;
drop database sms;

create table School_Admin(A_id int primary key,Email varchar(50),Password varchar(50));
select * from School_Admin;

create table Parent(Pid int primary key,Fname varchar(50),Lname varchar(50),Phone_Num varchar(50),Email varchar(50));

create table Examination(Exam_id int primary key,Exam_Date date,A_id int,foreign key (A_id) references School_Admin(A_id)on update cascade on delete cascade);

create table Student(Sid int primary key,Fname varchar(50),Lname varchar(50),DOB date,address varchar(50),Password varchar(50), Parent_id int,foreign key(Parent_id)references Parent(Pid)on update cascade on delete cascade,Phone_Num varchar(50),Joining_Date date,Email varchar(50),Gender varchar(50),fee int,Exam_Id int,foreign key (Exam_Id) references Examination(Exam_id)on update cascade on delete cascade,A_id int,foreign key(A_id) references School_Admin(A_id)on update cascade on delete cascade);

create table staff(Staff_id int primary key,Fname varchar(50),Lname varchar(50),Phone_Num varchar(50),Email varchar(50),DOB date,designation varchar(50),Gender varchar(50),Salary int,Admin_id int,foreign key(Admin_id)references School_Admin(A_id)on update cascade on delete cascade);

create table Teacher(Tid int primary key,Fname varchar(50),Lname varchar(50),Phone_Num varchar(50),Email varchar(50),Password varchar(50),DOB date,Qualification varchar(50),Gender varchar(50),Salary int,Staff_id int,foreign key (Staff_id) references staff(Staff_id)on update cascade on delete cascade);

create table Course(Cid int primary key,C_Name varchar(50),T_id int,foreign key (T_id)references Teacher(Tid)on update cascade on delete cascade);

create table studies(Cid int,foreign key (Cid) references Course(Cid)on update cascade on delete cascade,Sid int,foreign key (Sid) references Student(Sid)on update cascade on delete cascade);

create table teaches(Cid int,foreign key (Cid) references Course(Cid)on update cascade on delete cascade,Tid int,foreign key (Tid) references Teacher(Tid)on update cascade on delete cascade);

create table Time_Table(Class_Day varchar (50),Class_time time,primary key(Class_Day,Class_time));

create table organise(Class_Day varchar(50),Class_time time,foreign key (Class_Day,Class_time) references Time_Table(Class_Day,Class_time)on update cascade on delete cascade,Cid int,foreign key (Cid) references Course(Cid)on update cascade on delete cascade,primary key(Class_Day,Class_time));

create table Class(Class_Day varchar(50),Class_time time,foreign key (Class_Day,Class_time) references Time_Table(Class_Day,Class_time)on update cascade on delete cascade,R_id int, primary key(R_id,Class_Day,Class_time),section varchar(50),T_id int,foreign key (T_id)references Teacher(Tid)on update cascade on delete cascade);

create table Grade(Student_id int,foreign key(Student_id) references Student(Sid)on update cascade on delete cascade,Course_id int,foreign key(Course_id)references Course(Cid)on update cascade on delete cascade,Grade_Name varchar(50));



insert into School_Admin values(1,'hmm@xyz.edu.pk','letmein');

insert into Parent values(1,'Imran','Rashid','03310146526','xyz@gmail.com'),(2,'Taha','Asif','03318291032','xyz@gmail.com');
select* from Parent;

insert into Examination values(1,'2021-12-17',1),(2,'2021-12-18',1);
select* from Examination;

insert into Student values(1,'Musa','Khan','2001-2-8','H#1,st#2,Lahore','Musa2001',1,'03310146517','2021-1-17','musak1561@gmail.com','M',20000,1,1),(2,'Faraz','Asgher','2000-6-18','H#2,st#3,Lahore','xyz123$$',2,'03310152719','2020-1-17','faraz12@gmail.com','M',20000,1,1);
select* from Student;

insert into Staff values(1,'Muhammad','Sufyan','01399351678','Sufi420@gmail.com','2001-4-8','pn','m',5000,1),(2,'Mehwish','Shafiq','01329305810','mehwish20@gmail.com','2000-10-8','teacher','f',50000,1);
insert into Staff values(3,'Ayaz','Gillani','01340293179','Ayaz39@gmail.com','1989-10-8','teacher','m',50000,1);
select* from Staff;

insert into teacher values(1,'Mehwish','Shafiq','01329305810','mehwish20@gmail.com','ucp2020m','2000-10-8','Phd CS','f',50000,2);
insert into teacher values(2,'Ayaz','Gillani','01340293179','Ayaz39@gmail.com','123123','1989-10-8','Masters','m',50000,2);
select* from teacher;

insert into Course values(1,'DSA',1),(2,'COAL',1),(3,'DB',2);
select* from Course;

insert into studies values(1,1),(2,2);
select * from studies;

insert into teaches values(1,1),(2,1),(3,2);
select * from teaches;

insert into Time_Table values('Monday','1:30'),('Monday','2:30'),('Monday','3:00');
select * from Time_Table;

insert into organise values('Monday','1:30',1),('Monday','2:30',2),('Monday','3:00',3);
select * from organise;
insert into organise values('Monday','1:30',2);
insert into class values('Monday','1:30',1,'A',1),('Monday','2:30',2,'A',2),('Monday','3:00',3,'B',1);
select * from class;









alter table time_table add column pdate date;
alter table class drop p_id ;

alter table school_admin add column Password varchar(50);
alter table school_admin add column email varchar(50);
select* from school_admin;
select * from class;
select * from time_table;
select * from Grade;
select * from Teacher;
select * from Student;
select* from course;
select * from studies;

insert into grade values(1,1,'A+');